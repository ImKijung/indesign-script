#targetengine "session" 
var eventListener = app.addEventListener("afterOpen", selectPreFlight, false);

function selectPreFlight(myEvent) {
	// try {
	
	
}