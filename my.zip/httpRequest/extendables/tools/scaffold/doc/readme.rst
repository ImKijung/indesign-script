=================================================
``new project``: this is a new Extendables module
=================================================

..
    This readme should give a general overview of what this module contains
    and how other modules and scripts can use the functionality this module
    provides.
    
    You can add in autodocs from the JSDOC toolkit using e.g. 
    
    .. include:: jsdoc/MyClass.rst