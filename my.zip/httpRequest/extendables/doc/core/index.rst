.. _core:

====
Core
====

.. toctree::
   :maxdepth: 2
   
   writing-a-module
   contribute
   design-patterns
   roadmap
   changes