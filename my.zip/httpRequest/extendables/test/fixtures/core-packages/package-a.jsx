﻿var dirty = "this variable would pollute the global namespace and shouldn't survive module loading";

exports.this_is = "Package A";